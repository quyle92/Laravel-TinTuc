<?php

namespace Ajthinking\Tinx\Naming;

interface Strategy
{
    /**
     * @return array
     * */
    public function getNames();
}
